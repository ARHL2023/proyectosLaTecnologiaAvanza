package com.tecnico.servicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioTecnicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioTecnicoApplication.class, args);
	}

}
